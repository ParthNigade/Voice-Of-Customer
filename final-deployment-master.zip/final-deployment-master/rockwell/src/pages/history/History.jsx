import React from 'react'

const History = () => {
  return (
    <div className='container'>History</div>
  )
}

export default History
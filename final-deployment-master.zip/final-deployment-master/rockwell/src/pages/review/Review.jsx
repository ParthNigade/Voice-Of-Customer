import React from 'react'

const Review = () => {
  return (
    <div className='container'>Review</div>
  )
}

export default Review
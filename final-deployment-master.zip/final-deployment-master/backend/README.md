<h1>Rockwell Project client backend for User Query using GenAI</h1>

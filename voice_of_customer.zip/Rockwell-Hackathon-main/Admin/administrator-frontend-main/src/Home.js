import React from 'react';
import BarChart from './chart';

const Home = () => {
  return (

    <div className="App">
      <BarChart />
    </div>
  );
};

export default Home;

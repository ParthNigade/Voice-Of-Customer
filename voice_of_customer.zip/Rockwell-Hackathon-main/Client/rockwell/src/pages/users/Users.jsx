import React from 'react'

const Users = () => {
  return (
    <div className='container'>Users</div>
  )
}

export default Users
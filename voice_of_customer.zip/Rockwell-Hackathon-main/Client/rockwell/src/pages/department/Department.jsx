import React from 'react'

const Department = () => {
  return (
    <div className='container'>Department</div>
  )
}

export default Department